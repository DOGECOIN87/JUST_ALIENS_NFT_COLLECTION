document.addEventListener('DOMContentLoaded', () => {
  // Hamburger menu functionality (works on all pages)
  const hamburgerMenu = document.querySelector('.hamburger-menu');
  const sidebar = document.querySelector('.sidebar');
  
  if (hamburgerMenu && sidebar) {
    hamburgerMenu.addEventListener('click', (e) => {
      e.stopPropagation();
      hamburgerMenu.classList.toggle('active');
      sidebar.classList.toggle('active');
    });

    // Close sidebar when clicking outside
    document.addEventListener('click', (e) => {
      if (!sidebar.contains(e.target) && !hamburgerMenu.contains(e.target) && sidebar.classList.contains('active')) {
        hamburgerMenu.classList.remove('active');
        sidebar.classList.remove('active');
      }
    });
  }

  // Carousel functionality (only runs if carousel exists)
  const carousel = document.querySelector('.carousel');
  if (carousel) {
    const items = carousel.querySelectorAll('.carousel-item');
    let currentIndex = 0;

    function showNext() {
      items[currentIndex].classList.remove('active');
      currentIndex = (currentIndex + 1) % items.length;
      items[currentIndex].classList.add('active');
    }

    setInterval(showNext, 5000);
  }
});