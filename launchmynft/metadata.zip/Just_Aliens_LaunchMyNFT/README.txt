JUST ALIENS — LAUNCHMYNFT UPLOAD PACKAGE
420 lossless 1254 × 1254 PNGs, each with matching standard Metaplex JSON.

EXTRACT all four upload archives to the SAME folder. They share the root
Just_Aliens_LaunchMyNFT/upload/. Upload only its 840 PNG/JSON files using
LaunchMyNFT > Create > New Collection > Solana > upload your existing assets.
Do not upload audit files, proof images, or this readme as NFT assets.
Keep each N.png beside N.json; filenames run 1 through 420.
Image fields use matching local filenames for the launchpad to replace with hosted URIs.

SETTINGS
Supply: 420. Mint price: 0.005 SOL. Symbol: JSTA. Royalties: 5%.
Existing repository creator/payout address: Hn1i7bLb7oHpAL5AoyGvkn7YgwmWrVTbVsjXA1LYnELo; share: 100%.
Use the correct wallet and verify these settings on the launchpad before signing.
JSON royalties are metadata; configure royalties in the launchpad as well.
No wallet transaction, hosting upload, mint, or deployment has been performed.
Platform-side import has not been executed; package validation is local.

EXACT RARITIES
404 Normal = 96.190476%; 15 Rare = 3.571429%; 1 Secret Rare = 0.238095%.
Rare types: Android 5; Infantry 5; OG 5. Captions: 210 yes, 210 none.
One secret in 420 cannot equal the legacy 0.07% website percentage.
Normal headwear: 13 approved designs, 31 or 32 appearances each, restricted
to the 18 explicitly approved headwear/skin/expression fits.
49 editions use people backgrounds. The Gorlock/Warzone background, rejected
purple/gold hood and space helmets are excluded. Backgrounds alone receive
the very faint blur. Existing registered foreground layers remain untouched.

AUDIT
verification.json contains counts and checks. trait-frequencies.csv lists each
actual trait count and percentage. rarity-ranking.csv is an inverse-frequency
trait score, separate from the declared Type rarity tier. It is not uploaded
as an NFT attribute or a promised marketplace rank. recipes.json and source/
image hashes identify every input and output. All images and metadata are unique.

Sources: https://generator.launchmynft.io/ (supported output details),
https://docs.launchmynft.io/ (upload-existing-assets workflow), and
https://www.metaplex.com/docs/smart-contracts/token-metadata/token-standard
(off-chain JSON fields). Standard PNG is retained losslessly instead of WebP.
